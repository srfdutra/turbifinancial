package main

import (
	"bufio"
	"database/sql"
	"encoding/base64"
	"encoding/csv"
	"fmt"
	"io"
	"io/ioutil"
	"os" //	"os/exec"
	"os/exec"
	"strconv"

	"github.com/360EntSecGroup-Skylar/excelize"
	_ "github.com/go-sql-driver/mysql"
)

type XLSX struct {
	Batch           string
	PSPModification string
	PSPReference    string
	DateTransaction string
	GrossCredit     float64
	GrossDebit      float64
	NetCredit       float64
	NetDebit        float64
	Commission      float64
	DBvalue         float64
	Flag            string
}

type SumXLSX struct {
	Gross      float64
	Commission float64
	Net        float64
	GrossDB    float64
}

type DBValues struct {
	PSP   string
	Value float64
}

var AdyenUser string
var AdyenPass string
var AdyenURL string

var dsn = "root:GreatTeam8*@tcp(127.0.0.1:3307)/dbsqlt890"
var db, err = sql.Open("mysql", dsn)

func main() {

	ym := "2018-12"

	// WgetCSV()
	// MergeFiles()

	var sumXLSX SumXLSX
	var xlsx []XLSX
	var dbValues []DBValues

	dbValues = DirtyStruct(ym)

	filename := "merged.csv"

	var soma float64

	f, _ := os.Open(filename)
	g := 1
	r := csv.NewReader(bufio.NewReader(f))
	for {
		record, err := r.Read()
		if err == io.EOF {
			break
		}

		_, err = strconv.ParseInt(record[8], 10, 64)
		if err != nil {
		} else {
			runes := []rune(record[5])

			//fmt.Println(record[2])

			yearMonthSubstring := string(runes[0:7])
			if yearMonthSubstring == ym {
				var lineXlsx XLSX
				lineXlsx.PSPModification = record[8]
				lineXlsx.PSPReference = record[2]
				lineXlsx.Flag = record[4]
				lineXlsx.DateTransaction = record[5]

				_, err = strconv.ParseInt(record[22], 10, 64)
				if err == nil {
					lineXlsx.Batch = record[22]
				} else {
					lineXlsx.Batch = record[24]
				}

				lineXlsx.GrossDebit, err = strconv.ParseFloat(record[10], 64)
				lineXlsx.GrossCredit, err = strconv.ParseFloat(record[11], 64)
				lineXlsx.NetDebit, err = strconv.ParseFloat(record[14], 64)
				lineXlsx.NetCredit, err = strconv.ParseFloat(record[15], 64)
				lineXlsx.Commission, err = strconv.ParseFloat(record[16], 64)
				//lineXlsx.DBvalue = SelectDBValue(record[8])

				x := 0
				for x < len(dbValues) {
					if dbValues[x].PSP == record[8] {
						lineXlsx.DBvalue = dbValues[x].Value
					}
					x++
				}

				// Trata transações feitas diretamente na Adyen
				// if lineXlsx.DBvalue == 0 {
				// 	lineXlsx.DBvalue = lineXlsx.GrossDebit
				// }

				sumXLSX.Gross = sumXLSX.Gross + (lineXlsx.GrossCredit - lineXlsx.GrossDebit)
				sumXLSX.Commission = sumXLSX.Commission + lineXlsx.Commission
				sumXLSX.Net = sumXLSX.Net + (lineXlsx.NetCredit - lineXlsx.NetDebit)

				vGrossC, _ := strconv.ParseFloat(record[11], 64)
				if vGrossC != 0 {
					sumXLSX.GrossDB = sumXLSX.GrossDB + lineXlsx.DBvalue
				} else {
					sumXLSX.GrossDB = sumXLSX.GrossDB - lineXlsx.DBvalue
				}

				xlsx = append(xlsx, lineXlsx)

				//fmt.Println(lineXlsx)

				if lineXlsx.DBvalue == 0 {
					//fmt.Println(lineXlsx)
					soma = soma + lineXlsx.GrossDebit
				}
			}
		}
		g++

	}

	// fmt.Println(sumXLSX)
	// fmt.Println(soma)
	GenerateXLSX(xlsx, sumXLSX)

}

// GenerateXLSX ...
func GenerateXLSX(xlsxFull []XLSX, sumXLSX SumXLSX) {
	xlsx := excelize.NewFile()

	xlsx.SetCellValue("Sheet1", "A1", "Batch")
	xlsx.SetCellValue("Sheet1", "B1", "PSP Reference")
	xlsx.SetCellValue("Sheet1", "C1", "PSP Modification")
	xlsx.SetCellValue("Sheet1", "D1", "Flag")
	xlsx.SetCellValue("Sheet1", "E1", "Date Oparation")
	xlsx.SetCellValue("Sheet1", "F1", "Gross Credit")
	xlsx.SetCellValue("Sheet1", "G1", "Gross Debit")
	xlsx.SetCellValue("Sheet1", "H1", "Net Credit")
	xlsx.SetCellValue("Sheet1", "I1", "Net Debit")
	xlsx.SetCellValue("Sheet1", "J1", "Commission")
	xlsx.SetCellValue("Sheet1", "K1", "DB Value")
	xlsx.SetCellValue("Sheet1", "L1", "Adyen Operation")

	col := "0"
	count := 0
	line := 2
	for count < len(xlsxFull) {
		col = strconv.Itoa(line)
		xlsx.SetCellValue("Sheet1", "A"+col, xlsxFull[count].Batch)
		xlsx.SetCellValue("Sheet1", "B"+col, xlsxFull[count].PSPReference)
		xlsx.SetCellValue("Sheet1", "C"+col, xlsxFull[count].PSPModification)
		xlsx.SetCellValue("Sheet1", "D"+col, xlsxFull[count].Flag)
		xlsx.SetCellValue("Sheet1", "E"+col, xlsxFull[count].DateTransaction)
		xlsx.SetCellValue("Sheet1", "F"+col, xlsxFull[count].GrossCredit)
		xlsx.SetCellValue("Sheet1", "G"+col, xlsxFull[count].GrossDebit)
		xlsx.SetCellValue("Sheet1", "H"+col, xlsxFull[count].NetCredit)
		xlsx.SetCellValue("Sheet1", "I"+col, xlsxFull[count].NetDebit)
		xlsx.SetCellValue("Sheet1", "J"+col, xlsxFull[count].Commission)
		xlsx.SetCellValue("Sheet1", "K"+col, xlsxFull[count].DBvalue)
		if xlsxFull[count].DBvalue == 0 {
			xlsx.SetCellValue("Sheet1", "L"+col, xlsxFull[count].GrossDebit)
		}

		line++
		count++
	}

	xlsx.SetCellFormula("Sheet1", "L"+strconv.Itoa(line), "SUM(L1:L"+strconv.Itoa(line - 1))

	xlsx.SetCellValue("Sheet1", "F"+strconv.Itoa(line), strconv.FormatFloat(float64(sumXLSX.Gross), 'f', 2, 64))
	xlsx.SetCellValue("Sheet1", "H"+strconv.Itoa(line), strconv.FormatFloat(float64(sumXLSX.Net), 'f', 2, 64))
	xlsx.SetCellValue("Sheet1", "J"+strconv.Itoa(line), strconv.FormatFloat(float64(sumXLSX.Commission), 'f', 2, 64))
	xlsx.SetCellValue("Sheet1", "K"+strconv.Itoa(line), strconv.FormatFloat(float64(sumXLSX.GrossDB), 'f', 2, 64))

	xlsx.SetColWidth("Sheet1", "B", "C", 22)
	xlsx.SetColWidth("Sheet1", "E", "E", 22)
	xlsx.SetColWidth("Sheet1", "F", "K", 12)
	xlsx.SetColWidth("Sheet1", "L", "L", 15)

	xlsx.SetPanes("Sheet1", `{"freeze":true,"split":false,"x_split":1,"y_split":1,"top_left_cell":"B1","active_pane":"topRight"}`)

	// format1, _ := xlsx.NewConditionalStyle(`{"font":{"color":"#9A0511"},"fill":{"type":"pattern","color":["#FEC7CE"],"pattern":1}}`)

	// xlsx.SetConditionalFormat("Sheet1", "K1:K3000", fmt.Sprintf(`[{"type":"cell","criteria":"between","format":%d,"minimum":"0","maximum":"0"}]`, format1))

	err := xlsx.SaveAs("./Book1.xlsx")
	if err != nil {
		fmt.Println(err)
	}
}

// DirtyStruct ...
func DirtyStruct(dateTransaction string) (dbValues []DBValues) {
	results, err := db.Query("SELECT transactionid,value FROM transaction where DATE(transactiondate) like '" + dateTransaction + "%'")
	if err != nil {
		panic(err.Error())
	}

	var dbValue DBValues

	for results.Next() {
		err = results.Scan(&dbValue.PSP, &dbValue.Value)
		if err != nil {
			panic(err.Error())
		}

		dbValues = append(dbValues, dbValue)

	}

	return dbValues
}

// SelectDBValue ...
func SelectDBValue(psp string) float64 {
	var xlsx XLSX
	err = db.QueryRow("SELECT value FROM transaction where transactionid = ?", psp).Scan(&xlsx.DBvalue)
	if err != nil {
		return 0
	}

	return xlsx.DBvalue
}

// MergeFiles ...
func MergeFiles() {
	entries, _ := ioutil.ReadDir("CSV/")

	f, _ := os.Create("merged.csv")

	defer f.Close()

	i := 0
	for i < len(entries) {

		name := "CSV/" + entries[i].Name()

		b, _ := ioutil.ReadFile(name)

		f.Write(b)

		i++
	}
	f.Sync()

}

// WgetCSV ...
func WgetCSV() {
	cmd := exec.Command("wget",
		"--http-user=report@Company.TurbiBR",
		"--http-password=FH4Z5sV[6a3mmk\\pH(x=Y!*u+",
		"--directory-prefix=CSV/",
		"--no-check-certificate",
		"-nc",
		"-r",
		"-l1",
		"-H",
		"-t1",
		"-nd",
		"-np",
		"-Asettle*",
		"-erobots=off",
		"https://ca-live.adyen.com/reports/download/MerchantAccount/TurbiBRCOM")

	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Run()
	cmd.Process.Kill()
}

// DownloadCSV ...
func DownloadCSV() {

	// AdyenUser = "report@Company.TurbiBR"
	// AdyenPass = "FH4Z5sV[6a3mmk\\pH(x=Y!*u+"
	// AdyenURL = "https://ca-live.adyen.com/reports/download/MerchantAccount/TurbiBRCOM"

	// var header = map[string]string{
	// 	"Content-Type":  "application/json",
	// 	"Authorization": "Basic " + BasicAuth(AdyenUser, AdyenPass),
	// }

	// req, err := http.NewRequest("GET", AdyenURL, bytes.NewBuffer(jsonStr))
	// req.Header.Set("Content-Type",  "application/json")
	// req.Header.Set("Authorization" ,  "Basic " + BasicAuth(AdyenUser, AdyenPass))

	// client := &http.Client{}
	// resp, err := client.Do(req)
	// if err != nil {
	// 	return
	// }
	// defer resp.Body.Close()

	// fmt.Println("")
	// fmt.Println("response Status:", resp.Status)
	// fmt.Println("response Headers:", resp.Header)

	// body, _ := ioutil.ReadAll(resp.Body)

}

// BasicAuth ...
func BasicAuth(username, password string) string {
	auth := username + ":" + password
	return base64.StdEncoding.EncodeToString([]byte(auth))
}
